import re
# from preprocess import preprocess_data
import string
import os
import nltk
from nltk.tokenize import RegexpTokenizer
from nltk.corpus import stopwords
import re
from sdk import upload


def preprocess_data(sentence):
	sentence = sentence.lower()
	tokenizer = RegexpTokenizer(r'\w+')
	tokens = tokenizer.tokenize(sentence)
	# filtered_words = [w for w in tokens if not w in stopwords.words('english')]
	filtered_words = filter(lambda token: token not in (allwords), tokens)
	return " ".join(filtered_words)


frequency = {}

stopwords = open("english.txt","r")
allwords = stopwords.read()


dictwords = open("engmix.txt","r")
dictallwords = dictwords.read()


input = open("hash1.txt","r")
lines = input.read().lower()
print(lines)
print(len(lines))


# exwords = " ".join(exwords)

extracted_lines = preprocess_data(lines)
print(extracted_lines)
print len(extracted_lines)





# y = extracted_lines.split(" ")

x = extracted_lines.split(" ")
print x

exwords = []
for i in x:
	
		temp = i.split("_")
		if(temp>1):
			for y in temp:
				exwords.append(y)

		else:
			exwords.append(i)
	
print exwords


# final = preprocess_data(exwords)

final = " ".join(exwords)
print final


removed_everything = preprocess_data(final)

extracted_words = removed_everything




print(extracted_words)
print(len(extracted_words))

extracted_words = list(extracted_words.split(" "))


i=1
for i in range(len(extracted_words)):
	# temp = extracted_words[i]
	temp = nltk.stem.porter.PorterStemmer().stem(extracted_words[i])
	query="awk 'BEGIN{s=flag=0;}{if($1==\"";
	query+=temp
	query+="\")flag=1;}END {if(flag==1){printf \"Found\"}else{printf \"Not Found\"}}' engmix.txt "
	#print query
	res=os.popen(query).read()
	# print res
	if(res =="Found"):
		print temp
		extracted_words[i] = temp
	else:
		print extracted_words[i]

	# if(dictallwords.find(new)!= -1):
	# 	i=new

print(extracted_words)


for word in extracted_words:
    count = frequency.get(word,0)
    frequency[word] = count + 1


frequency_list = frequency.keys()
 
for words in frequency_list:
    print words, frequency[words]
    upload(words, frequency[words])


key_max = max(frequency.keys(), key = (lambda k: frequency[k]))
key_min = min(frequency.keys(), key = (lambda k: frequency[k]))

print "Current Trending Frequency:", frequency[key_max]
print "Least Trending Frequency:", frequency[key_min]


vals = frequency.values()
maxVal, minVal = max(vals), min(vals)
minVals, maxVals = [], []
for k in frequency.iterkeys():
    if frequency[k] == maxVal:
        
        maxVals.append((k, maxVal))


    elif frequency[k] == minVal:
        minVals.append((k, minVal))



print "\n"
print "!!!! Current Trending Topics !!!!\n"


for i in maxVals:
	temp = i
	print temp[0]
	



print "\n"

print "!!!! Least Trending Topics !!!!\n"

for i in minVals:
	temp = i
	print temp[0]
	



# print maxVals
# print minVals
# print (extracted_words)

# for i in range(len(lines)):
# 	print(lines[i])
# 	print ("\n")




# words = lines.split(" ")


# length = len(words)
# print(" ")
# print (length)


# for i in range(length):
# 	print words[i]

