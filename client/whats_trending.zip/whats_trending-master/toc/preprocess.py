import string
import nltk
from nltk.tokenize import RegexpTokenizer
from nltk.corpus import stopwords
import re

stopwords = open("english.txt","r")
allwords = stopwords.read()

def preprocess_data(sentence):
	# sentence = sentence.lower()
	tokenizer = RegexpTokenizer(r'\w+')
	tokens = tokenizer.tokenize(sentence)
	# filtered_words = [w for w in tokens if not w in stopwords.words('english')]
	filtered_words = filter(lambda token: token not in (allwords), tokens)
	return " ".join(filtered_words)

sentence = "a Hindu festival with lights, held in the period October to November. It is particularly associated with Lakshmi, the goddess of prosperity, and marks the beginning of the financial year in India."
input = sentence.split(" ")
print input
print "____________________________________"
print preprocess_data(sentence)