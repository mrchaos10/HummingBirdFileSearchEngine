from firebase import firebase
from time import sleep

firebase = firebase.FirebaseApplication('https://test-firebase-db-f7bc7.firebaseio.com/', None)



new_user = 'Arun'

result = firebase.post('/users', new_user)
# print result
# {u'name': u'-Io26123nDHkfybDIGl7'}


# result = firebase.post('/users', new_user, {'print': 'silent'}, {'X_FANCY_HEADER': 'VERY FANCY'})
print result == None

# True










# result = firebase.get('/users', None)
# print result
# {'1': 'John Doe', '2': 'Jane Doe'}