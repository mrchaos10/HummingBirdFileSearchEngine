import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

cred = credentials.Certificate('cuic-6a789-firebase-adminsdk-1rlm4-606d1eccc2.json')
default_app = firebase_admin.initialize_app(cred, {
    'databaseURL' : 'https://cuic-6a789.firebaseio.com'
})

root = db.reference()
new_user = root.child('company')
def upload(x,y):
	
	# Add a new user under /users.
	new_user.push({
	
	    'comDate' : y, 
	    'comId' :1,
	    'comName':x
	
	})

# root = db.reference("Current")
# new = root.child('CurrentTrending')

# def upload_CurrentlsTrending(x):
	
# 	# Add a new user under /users.
# 	new.push({
	
# 	    'Trending Word' : x  
	
# 	})	



# root = db.reference("Least")

# new1 = root.child('LeastTrending')

# def upload_LeastTrending(x):
	
# 	# Add a new user under /users.
# 	new1.push({
	
# 	    'Trending Word' : x  
	
# 	})	



# default_app = firebase_admin.initialize_app()
